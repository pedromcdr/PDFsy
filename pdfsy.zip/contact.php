<?php
/**
 * PDFsy — contact form handler.
 * The destination address lives only here, on the server; it is never sent to the browser.
 */
declare(strict_types=1);

const PDFSY_TO        = 'hello@pdfsy.com';
const PDFSY_FROM      = 'no-reply@pdfsy.com';   // must be an address on the pdfsy.com domain for good deliverability
const PDFSY_RATE_MAX  = 5;                       // messages per IP...
const PDFSY_RATE_SECS = 3600;                    // ...per hour

$wantsJson = isset($_SERVER['HTTP_ACCEPT']) && strpos($_SERVER['HTTP_ACCEPT'], 'application/json') !== false;
$allowedLangs = ['en','pt','es','fr','de','it','nl','ca','pl','sv','tr','ru','uk','bg','el','ar','hi','th','id','ms','vi','ja','ko','zh-cn','zh-tw'];

function pdfsy_done(bool $ok, string $error = ''): void {
    global $wantsJson, $allowedLangs;
    if ($wantsJson) {
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        if (!$ok) http_response_code($error === 'rate' ? 429 : 400);
        echo json_encode(['ok' => $ok, 'error' => $error]);
        exit;
    }
    $lang = isset($_POST['lang']) ? strtolower((string)$_POST['lang']) : 'en';
    $path = ($lang === 'en' || !in_array($lang, $allowedLangs, true)) ? '/contact.html' : '/' . $lang . '/contact.html';
    header('Location: ' . $path . '?sent=' . ($ok ? '1' : '0'), true, 303);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    http_response_code(405);
    exit;
}

// Honeypot: real people never fill this hidden field.
if (!empty($_POST['website'])) pdfsy_done(true);

// Bots tend to submit instantly after load.
$ts = isset($_POST['ts']) ? (int)$_POST['ts'] : 0;
if ($ts > 0 && (microtime(true) * 1000 - $ts) < 2500) pdfsy_done(true);

$clean = static function (string $key, int $max): string {
    $v = isset($_POST[$key]) ? trim((string)$_POST[$key]) : '';
    $v = str_replace("\0", '', $v);
    return mb_substr($v, 0, $max, 'UTF-8');
};
$name    = $clean('name', 120);
$email   = $clean('email', 200);
$subject = $clean('subject', 200);
$message = $clean('message', 8000);
$lang    = $clean('lang', 10);

if ($name === '' || $subject === '' || $message === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    pdfsy_done(false, 'invalid');
}
// No header injection through single-line fields.
foreach ([$name, $email, $subject] as $v) {
    if (preg_match('/[\r\n]/', $v)) pdfsy_done(false, 'invalid');
}

// Simple per-IP rate limit (file based, no database needed).
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$rateFile = rtrim(sys_get_temp_dir(), '/') . '/pdfsy_rate_' . hash('sha256', $ip);
$now = time();
$hits = [];
if (is_file($rateFile)) {
    $hits = array_filter(array_map('intval', explode(',', (string)@file_get_contents($rateFile))), static fn($t) => $t > $now - PDFSY_RATE_SECS);
}
if (count($hits) >= PDFSY_RATE_MAX) pdfsy_done(false, 'rate');
$hits[] = $now;
@file_put_contents($rateFile, implode(',', $hits), LOCK_EX);

$encode = static fn(string $s): string => '=?UTF-8?B?' . base64_encode($s) . '?=';
$body  = "Nome / Name: {$name}\n";
$body .= "Email: {$email}\n";
$body .= "Língua / Language: {$lang}\n";
$body .= "IP: {$ip}\n";
$body .= "Data / Date: " . gmdate('Y-m-d H:i:s') . " UTC\n";
$body .= str_repeat('-', 40) . "\n\n" . $message . "\n";

$headers  = 'From: ' . $encode('PDFsy') . ' <' . PDFSY_FROM . ">\r\n";
$headers .= 'Reply-To: ' . $encode($name) . ' <' . $email . ">\r\n";
$headers .= "MIME-Version: 1.0\r\n";
$headers .= "Content-Type: text/plain; charset=UTF-8\r\n";
$headers .= "Content-Transfer-Encoding: 8bit\r\n";
$headers .= "X-Mailer: PDFsy contact form\r\n";

$sent = @mail(PDFSY_TO, $encode('[PDFsy] ' . $subject), $body, $headers, '-f' . PDFSY_FROM);
pdfsy_done($sent, $sent ? '' : 'send');
